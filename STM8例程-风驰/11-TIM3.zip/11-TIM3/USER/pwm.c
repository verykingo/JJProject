/******************** (C) COPYRIGHT  ���iCreateǶ��ʽ���������� ********************/
#include "pwm.h"

static void Delay(u16 nCount);

void PWM_Init(void)
{
 
  #if TIM3_Channel==TIM3_Channel1
    /*TIM3 Frequency = TIM3 counter clock/(ARR + 1) */
    TIM3_TimeBaseInit(TIM3_PRESCALER_16, 499);
    /*TIM3 Frequency=16M/16/(499+1)=2K*/
    /* PWM1 Mode configuration: Channel1
    TIM3 Channel1 duty cycle = [TIM3_CCR1/(TIM3_ARR + 1)] * 100 = 50%*/ 
    TIM3_OC1Init(TIM3_OCMODE_PWM1, TIM3_OUTPUTSTATE_ENABLE,250, TIM3_OCPOLARITY_HIGH);
    TIM3_OC1PreloadConfig(ENABLE);
    
  #elif TIM3_Channel==TIM3_Channel2
    TIM3_TimeBaseInit(TIM3_PRESCALER_16, 999);
    TIM3_OC2Init(TIM3_OCMODE_PWM2, TIM3_OUTPUTSTATE_ENABLE,500, TIM3_OCPOLARITY_HIGH);
    TIM3_OC2PreloadConfig(ENABLE);
    

  #endif
    
  TIM3_Cmd(ENABLE);
  
}

void SetTIM3_PWM_Frequency(uint16_t TIM3_Period)
{
      /* Set the Autoreload value */
  
    TIM3->ARRH = (uint8_t)(TIM3_Period >> 8);
    TIM3->ARRL = (uint8_t)(TIM3_Period);
}

void SetTIM3_PWM_DutyCycle( uint16_t TIM3_Pulse)
{
  
    
  #if TIM3_Channel==TIM3_Channel1
    /* Set the Pulse value */
    TIM3->CCR1H = (uint8_t)(TIM3_Pulse >> 8);
    TIM3->CCR1L = (uint8_t)(TIM3_Pulse);
    
  #elif TIM3_Channel==TIM3_Channel2
    TIM3->CCR2H = (uint8_t)(TIM3_Pulse >> 8);
    TIM3->CCR2L = (uint8_t)(TIM3_Pulse);
   
  #endif
}

void TestPWM_LED(void)
{
  u16 Duty_Val;
  for(Duty_Val=0;Duty_Val<499;Duty_Val++)
  {
    SetTIM3_PWM_DutyCycle(Duty_Val);
    Delay(0xfff);
  }
}


static void Delay(u16 nCount)
{
  /* Decrement nCount value */
  while (nCount != 0)
  {
    nCount--;
  }
}


/******************* (C) COPYRIGHT ���iCreateǶ��ʽ���������� *****END OF FILE****/