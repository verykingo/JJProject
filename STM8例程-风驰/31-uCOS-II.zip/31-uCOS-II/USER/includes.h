/*
********************************************************************************
*                                  uC/OS-II
*                             The Real-Time Kernel
*
*              (c) Copyright 1992-1999, Jean J. Labrosse, Weston, FL
*                             All Rights Reserved
*
*                             MASTER INCLUDE FILE
********************************************************************************
*/

/* ϵͳͷ�ļ� */
#include	<intrinsics.h>
#include	<stdlib.h>
#include	<string.h>

/* stm8���ͷ�ļ� */
#include	"stm8s.h"
#include	"sysclock.h"
#include	"tim1.h"
#include	"led.h"

/* uCOSϵͳͷ�ļ� */
#include	"ucos_ii.h"
#include	"os_cpu.h"
#include	"os_cfg.h"


