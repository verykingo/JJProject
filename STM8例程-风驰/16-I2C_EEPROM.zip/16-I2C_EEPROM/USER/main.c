/******************* (C) COPYRIGHT  ��۵���Ƕ��ʽ���������� *******************
 * �ļ���  ��main.c
 * ����    ��I2C EPPROM �Ķ�д     
 * ʵ��ƽ̨����۵���STM8������
 * ��汾  ��V2.1.0
 * ����    ��ling_guansheng     QQ:779814207
 * ����    ��
 * �޸�ʱ�� ��2012-12-20
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"
#include "sysclock.h"
#include "uart1.h"
#include "i2c_eeprom.h"

u8 Write_Buffer[] = {"STM8S I2C For One Byte And One Or Multiple Page Read And Write Example\
                     ---FengChi"};
/* Private variables ---------------------------------------------------------*/

#define countof(a) (sizeof(a) / sizeof(*(a)))
#define BufferSize             (countof(Write_Buffer)-1)
u8 Read_Buffer[BufferSize];

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

int main(void)
{
    /*�����ⲿ24M����Ϊ��ʱ��*/ 
    SystemClock_Init(HSE_Clock);
    Uart1_Init();
    /* ��ʼ�� I2C */ 
    I2C_MASTERMODE_Init(FASTSPEED);
    I2C_EEPROM_WriteMultiplePage(Write_Buffer, EEPROM_BASE_ADDRESS, BufferSize);
    I2C_EEPROM_ReadBuffer(Read_Buffer, EEPROM_BASE_ADDRESS, BufferSize);
    printf("What is read from Multiple page of AT24C02 EEPROM: %s\r\n", Read_Buffer);
	
    while (1)
	;
}





#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT ��۵���Ƕ��ʽ���������� *****END OF FILE****/
