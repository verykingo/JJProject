/***************** (C) COPYRIGHT  ���iCreateǶ��ʽ���������� ******************
 * �ļ���  ��main.c
 * ����    ��Flash_eeprom��дʵ��    
 * ʵ��ƽ̨��iCreate STM8������
 * ��汾  ��V2.1.0
 * ����    ����� QQ:779814207
 * ����    ��
 * �Ա�    ��http://shop71177993.taobao.com/
 * �޸�ʱ�� ��2012-12-8
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"
#include "sysclock.h"
#include "uart1.h"
#include "flash_eeprom.h"

void Delay(u16 nCount);

u8 WriteBuffer[FLASH_BLOCK_SIZE] = "This is a Flash Data Memory write and read test...by-��� @2012-12-10";
u8 ReadBuffer[FLASH_BLOCK_SIZE];
/* Private defines -----------------------------------------------------------*/
#define countof(a)   (sizeof(a) / sizeof(*(a)))
#define WriteTOEEpromNum   (countof(WriteBuffer) - 1)
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

int main(void)
{
	
  	/*�����ⲿʱ��24MΪ��ʱ��*/ 
  	SystemClock_Init(HSE_Clock);
	
	Uart1_Init();
	
	FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
        
	FLASH_EraseBlock(Block_1, FLASH_MEMTYPE_DATA);/*��FLASHд����ǰ��Ҫ������Ӧ������*/
        FLASH_WaitForLastOperation(FLASH_MEMTYPE_DATA);
        
	WriteMultiBlockByte(Block_1,FLASH_MEMTYPE_DATA,FLASH_PROGRAMMODE_STANDARD,WriteBuffer,1);
        
        ReadMultiBlockByte(Block_1,1,ReadBuffer);
        
        printf("\r\nWhat Read From Flash_EEPROM's Byte of Block%d is:%s\r\n", Block_1,ReadBuffer);
        
	while (1);
}


void Delay(u16 nCount)
{
  /* Decrement nCount value */
  while (nCount != 0)
  {
    nCount--;
  }
}



#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT ���iCreateǶ��ʽ���������� *****END OF FILE****/
